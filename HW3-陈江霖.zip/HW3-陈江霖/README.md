# 说明

## 环境与版本信息

- **GPU 硬件**：NVIDIA GeForce RTX 4090D (24GB) × 4
- **GPU 驱动**：580.105.08
- **操作系统**：Ubuntu 22.04 LTS (Docker 容器)
- **Python**：3.11
- **PyTorch**：2.5.1+cu124
- **CUDA**：12.4
- **SGLang**：0.4.6.post2
- **Ray**：2.9.0
- **模型**：Qwen/Qwen3-0.6B (本地路径: /root/autodl-tmp/Qwen3-0.6B/)
## 安装方法
在多次在autodl租借镜像无法解决兼容性问题后，选择了用社区镜像hiyouga/LLaMA-Factory/tzwm_LLaMA-Factory:v1进行初始配置，然后再下载ray；可能是因为这是去年的镜像，所以后续实验仍然出现了一定的文本字符与教学负载无法匹配的兼容性问题，后续同通过ai调试解决
## 脚本用途
- start_cluster 启动ray集群
- flush_cache 清理缓存
- app_rebuild 控制压发脚本的去向，a,b,c,d组通用，只需在注释处修改参数即可
- app_ab/c/d 一共三个脚本，ab组使用时在注释处修改最大并行数即可，c，d组则分别有一个自己的代码
- deploy—_ab/c/d一共三个，与上配套的部署脚本